from MiniMachineVM import MiniVM

minivm = MiniVM()
minivm.run()