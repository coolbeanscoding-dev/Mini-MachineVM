class MiniVM:
  def OpenFile(self):
    with open("program.masm", "r") as f:
      self.program = f.read()
    return self.program

  def __init__(self):
    self.stack = [0] * 10
    self.SP = 9
    self.PC = 0
    self.TPC = 0
  
  def load(self, Value):
    self.stack[self.SP] = Value
    
  def intload(self,Value):
    self.stack[self.SP] = int(Value)
  
  def remove(self):
    self.stack[self.SP] = 0
    
  def shiftup(self,index):
    index = int(index)
    self.SP += index
    if self.SP >= len(self.stack):
      print("Error: Stack Overflow")
      self.SP = len(self.stack) - 1
  
  def shiftdown(self,index):
    index = int(index)
    self.SP -= index
    if self.SP < 0:
      self.SP = 0
      print("Error: Stack Underflow")
    
  def add(self):
    if self.SP >= 1:
      a = self.stack[self.SP]
      self.SP -= 1
      b = self.stack[self.SP]
      c = a + b
      self.SP += 1
      self.load(c)
  
  def sub(self):
    if self.SP >= 1:
      a = self.stack[self.SP]
      self.SP -= 1
      b = self.stack[self.SP]
      c = a - b
      self.SP += 1
      self.load(c)
      
  def jump(self, PCJUMP):
    if type(PCJUMP) != int:
      pass
    self.PC = PCJUMP
  
  def PRINT(self):
    if 0 <= self.SP < len(self.stack):
      print(self.stack[self.SP])
    else:
      print("Error: Invalid stack pointer")
    
  def run(self):
    self.program = self.OpenFile()
    bytecode = self.program.strip().split()
    
    while self.PC < len(bytecode):
      if bytecode[self.PC] == "LOAD":
        if self.PC + 1 < len(bytecode):
          self.load(bytecode[self.PC + 1])
        self.PC += 2
        self.TPC += 1
      
      elif bytecode[self.PC] == "INTLOAD":
        if self.PC + 1 < len(bytecode):
          self.intload(bytecode[self.PC + 1])
        self.PC += 2
        self.TPC += 1
        
      elif bytecode[self.PC] == "REMOVE":
        self.remove()
        self.PC += 1
        self.TPC += 1
        
      elif bytecode[self.PC] == "SHIFT+":
        if self.PC + 1 < len(bytecode):
          self.shiftup(bytecode[self.PC + 1])
        self.PC += 2
        self.TPC += 1
        
      elif bytecode[self.PC] == "SHIFT-":
        if self.PC + 1 < len(bytecode):
          self.shiftdown(bytecode[self.PC + 1])
        self.PC += 2
        self.TPC += 1
        
      elif bytecode[self.PC] == "ADD":
        a = self.stack[self.SP]
        self.SP -= 1
        b = self.stack[self.SP]
        c = a + b
        self.SP += 1
        self.load(c)
        self.PC += 1
        self.TPC += 1
        
      elif bytecode[self.PC] == "SUB":
        a = self.stack[self.SP]
        self.SP -= 1
        b = self.stack[self.SP]
        c = a - b
        self.SP += 1
        self.load(c)
        self.PC += 1
        self.TPC += 1
      
      elif bytecode[self.PC] == "PRINT":
        if 0 <= self.SP < len(self.stack):
          print(self.stack[self.SP])
        else:
          print("Error: Invalid stack pointer")
        self.PC += 1
        self.TPC += 1
      
      elif bytecode[self.PC] == "HALT":
        break
